function greet() {
    console.log('Have a great day!');
};

export default greet;