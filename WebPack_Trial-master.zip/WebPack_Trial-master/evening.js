function evening() {
    console.log('This is my evening!');
};

export default evening;