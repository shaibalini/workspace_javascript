import greet from './greeter';
import evening from './evening';

console.log("I'm the entry point");
greet();
evening();